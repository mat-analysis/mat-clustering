matclustering.methods.coclustering namespace
============================================

.. py:module:: matclustering.methods.coclustering

Submodules
----------

matclustering.methods.coclustering.OCoClus module
-------------------------------------------------

.. automodule:: matclustering.methods.coclustering.OCoClus
   :members:
   :undoc-members:
   :show-inheritance:

matclustering.methods.coclustering.SSOCoClus module
---------------------------------------------------

.. automodule:: matclustering.methods.coclustering.SSOCoClus
   :members:
   :undoc-members:
   :show-inheritance:
