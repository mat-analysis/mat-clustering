matclustering.methods.hierarchical.mattree.metrics\_evaluation namespace
========================================================================

.. py:module:: matclustering.methods.hierarchical.mattree.metrics_evaluation

Submodules
----------

matclustering.methods.hierarchical.mattree.metrics\_evaluation.eda module
-------------------------------------------------------------------------

.. automodule:: matclustering.methods.hierarchical.mattree.metrics_evaluation.eda
   :members:
   :undoc-members:
   :show-inheritance:

matclustering.methods.hierarchical.mattree.metrics\_evaluation.entropy module
-----------------------------------------------------------------------------

.. automodule:: matclustering.methods.hierarchical.mattree.metrics_evaluation.entropy
   :members:
   :undoc-members:
   :show-inheritance:

matclustering.methods.hierarchical.mattree.metrics\_evaluation.freq\_matrix module
----------------------------------------------------------------------------------

.. automodule:: matclustering.methods.hierarchical.mattree.metrics_evaluation.freq_matrix
   :members:
   :undoc-members:
   :show-inheritance:

matclustering.methods.hierarchical.mattree.metrics\_evaluation.sankey module
----------------------------------------------------------------------------

.. automodule:: matclustering.methods.hierarchical.mattree.metrics_evaluation.sankey
   :members:
   :undoc-members:
   :show-inheritance:

matclustering.methods.hierarchical.mattree.metrics\_evaluation.similarity\_matrix module
----------------------------------------------------------------------------------------

.. automodule:: matclustering.methods.hierarchical.mattree.metrics_evaluation.similarity_matrix
   :members:
   :undoc-members:
   :show-inheritance:
