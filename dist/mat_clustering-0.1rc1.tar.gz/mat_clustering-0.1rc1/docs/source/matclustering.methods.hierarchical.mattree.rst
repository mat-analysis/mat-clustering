matclustering.methods.hierarchical.mattree namespace
====================================================

.. py:module:: matclustering.methods.hierarchical.mattree

Subpackages
-----------

.. toctree::
   :maxdepth: 10

   matclustering.methods.hierarchical.mattree.algorithm
   matclustering.methods.hierarchical.mattree.metrics_evaluation

Submodules
----------

matclustering.methods.hierarchical.mattree.MATTree module
---------------------------------------------------------

.. automodule:: matclustering.methods.hierarchical.mattree.MATTree
   :members:
   :undoc-members:
   :show-inheritance:
