matclustering package
=====================

Subpackages
-----------

.. toctree::
   :maxdepth: 10

   matclustering.core
   matclustering.methods

Module contents
---------------

.. automodule:: matclustering
   :members:
   :undoc-members:
   :show-inheritance:
