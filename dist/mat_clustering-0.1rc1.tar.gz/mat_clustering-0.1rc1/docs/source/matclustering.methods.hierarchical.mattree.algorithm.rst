matclustering.methods.hierarchical.mattree.algorithm namespace
==============================================================

.. py:module:: matclustering.methods.hierarchical.mattree.algorithm

Submodules
----------

matclustering.methods.hierarchical.mattree.algorithm.TreeNodeObject module
--------------------------------------------------------------------------

.. automodule:: matclustering.methods.hierarchical.mattree.algorithm.TreeNodeObject
   :members:
   :undoc-members:
   :show-inheritance:

matclustering.methods.hierarchical.mattree.algorithm.check\_label module
------------------------------------------------------------------------

.. automodule:: matclustering.methods.hierarchical.mattree.algorithm.check_label
   :members:
   :undoc-members:
   :show-inheritance:

matclustering.methods.hierarchical.mattree.algorithm.dashtree module
--------------------------------------------------------------------

.. automodule:: matclustering.methods.hierarchical.mattree.algorithm.dashtree
   :members:
   :undoc-members:
   :show-inheritance:

matclustering.methods.hierarchical.mattree.algorithm.graphic\_tree module
-------------------------------------------------------------------------

.. automodule:: matclustering.methods.hierarchical.mattree.algorithm.graphic_tree
   :members:
   :undoc-members:
   :show-inheritance:

matclustering.methods.hierarchical.mattree.algorithm.set\_level module
----------------------------------------------------------------------

.. automodule:: matclustering.methods.hierarchical.mattree.algorithm.set_level
   :members:
   :undoc-members:
   :show-inheritance:
