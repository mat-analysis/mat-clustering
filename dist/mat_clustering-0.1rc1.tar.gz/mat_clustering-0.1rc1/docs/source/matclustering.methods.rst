matclustering.methods package
=============================

Subpackages
-----------

.. toctree::
   :maxdepth: 10

   matclustering.methods.coclustering
   matclustering.methods.hierarchical
   matclustering.methods.similarity

Module contents
---------------

.. automodule:: matclustering.methods
   :members:
   :undoc-members:
   :show-inheritance:
