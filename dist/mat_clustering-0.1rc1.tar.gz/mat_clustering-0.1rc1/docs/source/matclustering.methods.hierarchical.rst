matclustering.methods.hierarchical package
==========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 10

   matclustering.methods.hierarchical.mattree

Module contents
---------------

.. automodule:: matclustering.methods.hierarchical
   :members:
   :undoc-members:
   :show-inheritance:
